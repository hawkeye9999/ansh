from flask import Blueprint, request, render_template, abort, session, redirect, url_for
from app import mysql
import MySQLdb.cursors
from datetime import date
import datetime
import json,pytz,requests, base64, math
from check_login import login_required

quiz = Blueprint('quiz', __name__,template_folder='templates')
IST = pytz.timezone('Asia/Kolkata')
# @quiz.route('/home')
# @quiz.route('/')
# def quizes_all_a():
#     return render_template('all_quizes.html',message = "", quizes = "",total_q = len(0),color=[])
    

@quiz.route('/all_quizes/')
@login_required
def quizes_all():
    mode = session['mode']
    svv = session['svv']
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    qs = list()
    colors = ['bg-gradient-primary2','bg-gradient-success','bg-gradient-info','bg-gradient-warning','bg-gradient-danger','bg-gradient-dark']
    if mode=="Faculty":
        cursor.execute('SELECT quiz_id,q_title,q_sub,q_date,q_time_start,q_time_end FROM quiz_det WHERE fac_inserted =%s ORDER BY quiz_id DESC', [svv])
        records = cursor.fetchall()
        cursor.close()
        for row in records:
            row['q_date'] = datetime.datetime.strptime(row['q_date'], '%Y-%m-%d').strftime('%d/%m/%y')
            qs.append(row)
        return render_template('all_quizes.html', message="", quizes = qs,total_q = len(records),color=colors)
    elif mode=="Student":
        dept = session['dept']
        sem = session['sem']
        batch = session['batch']
        cursor.execute('SELECT quiz_id,q_title,q_sub,q_date,q_time_start,q_time_end FROM quiz_det WHERE q_dept = %s AND q_sem = %s AND q_batch="All" OR  q_batch=%s ORDER BY quiz_id DESC', (dept,sem,batch))
        records = cursor.fetchall()
        cursor.close()
        for row in records:
            row['q_date'] = datetime.datetime.strptime(row['q_date'], '%Y-%m-%d').strftime('%d/%m/%y')
            qs.append(row)
        return render_template('all_quizes.html', message="", quizes = qs,total_q = len(records),color=colors)

@quiz.route('/CreateQuiz/')
@login_required
def create_quiz():
    if not session.get("mode") is None:
        if session['mode']=="Faculty":
            return render_template("create_quiz.html")
        return redirect(url_for('bad_request'))

@quiz.route('/check_others_time/',methods=['POST'])
def check_other_quiz_time():
    dept =  request.form['dept']
    sem = request.form['sem']
    batch =  request.form['batch']
    if session.get('quiz_id') is not None:
        quiz_id = session['quiz_id']
    date = datetime.datetime.strptime(request.form['date'], '%Y-%m-%d').date()
    # #print("Date:",date)
    # #print("dept:",dept)
    # #print("sem:",sem)
    # #print("batch:",batch)
    s_time =  datetime.datetime.strptime(request.form['s_time'],'%H:%M').time()
    e_time =  datetime.datetime.strptime(request.form['e_time'],'%H:%M').time()
    # #print("s_time:",s_time)
    # #print("e_time:",e_time)
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    if session.get('quiz_id') is None:
        cursor.execute('SELECT q_time_start,q_time_end FROM quiz_det WHERE q_date = %s AND q_dept = %s AND q_sem = %s AND q_batch = %s', (date,dept,sem,batch))
    else:
        cursor.execute('SELECT q_time_start,q_time_end FROM quiz_det WHERE q_date = %s AND q_dept = %s AND q_sem = %s AND q_batch = %s AND quiz_id!=%s', (date,dept,sem,batch,quiz_id))
    # # #print(cursor._last_executed)
    records = cursor.fetchall()
    value_present = 0
    # #print(records)
    for row in records:
        f_stime = datetime.datetime.strptime(row['q_time_start'],'%H:%M').time()
        f_etime = datetime.datetime.strptime(row['q_time_end'],'%H:%M').time()
        # #print("f_stime:",f_stime)
        # #print("f_etime:",f_etime)
        if s_time >= f_stime and s_time<= f_etime:
            value_present = 1
            break
        elif e_time >= f_stime and e_time<= f_etime:
            value_present = 1
            break
        else:
            value_present = 0
    # #print("Value present:",value_present)
    rt_str = ''
    if value_present==1:
        rt_str = 'Yes'
    elif value_present==0:
        rt_str = 'No'
    return json.dumps(rt_str)


@quiz.route('/getsubjects/',methods=['POST'])
def get_subjects():
    dept =  request.form['dept']
    sem = 'sem'+request.form['sem']
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT \
        subject.subject_name AS s_name \
        FROM subject \
        INNER JOIN department ON subject.dept_id = department.dept_id \
        WHERE department.dept_short = %s AND subject.sem = %s', (dept,sem))
    records = cursor.fetchall()
    # #print(type(records))
    subjects = list()    
    for row in records:
        subjects.append(row['s_name'])
    # #print(subjects)

    cursor.close()
    return json.dumps(subjects)

@quiz.route('/add_quiz_info/',methods=['POST'])
@login_required
def add_quiz_information():
    title =  request.form['quiz_title']
    dept =  request.form['dept']
    sem =  request.form['sem']
    batch =  request.form['batch']
    date =  request.form['date']
    s_time =  request.form['s_time']
    e_time =  request.form['e_time']
    fac_inserted = session['svv']
    view_score =  request.form['view_score']
    ques_timer =  request.form['ques_timer']
    quiz_type = request.form['quiz_type']
    switch_limit = request.form['switch_limit']
    desc_time = request.form['desc_time']
    # #print(quiz_type)
    # #print('Ques Time:',ques_timer)
    if view_score=='Yes':
        view_score = 1
    else:
        view_score = 0
    if ques_timer=='Yes':
        ques_timer = 1
        q_time_divide =  request.form['q_time_divide']
    else:
        ques_timer = 0
        q_time_divide = '-'
    if quiz_type=='1':
        sub = ''
    else:
        sub =  request.form['sub']
    # #print('sub',sub)
    # #print('quiz_type',quiz_type)
    # preview_quiz_questiont(q_date)
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    result = cur.execute("INSERT INTO quiz_det (q_title,q_dept,q_sem,q_sub,q_batch,q_date,q_time_start,q_time_end,show_answer,fac_inserted,q_timer,q_time_division,quiz_type,switch_limit,desc_time) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(title,dept,sem,sub,batch,date,s_time,e_time,view_score,fac_inserted,ques_timer,q_time_divide,quiz_type,switch_limit,desc_time))    
    session.pop("quiz_id",None)
    session.pop("ques_no",None)
    session['quiz_id'] = str(cur.lastrowid)
    session['ques_timer'] = ques_timer
    if q_time_divide!='-':
        session['q_time_division'] = q_time_divide
        # #print(session['q_time_division'])
    # #print("QUiz ID:",session['quiz_id'])
    # #print("QUiz Timer:",session['ques_timer'])
    mysql.connection.commit()
    return redirect(url_for('quiz.add_quiz_details'))    

@quiz.route('/add_quiz_det/')
@login_required
def add_quiz_details():
    if not session.get("ques_no") is None:
        print('')
        # #print("ques_no in add quiz det:"+str(session['ques_no']))
        # session['ques_no'] = int(session['ques_no'])+1
    else:
        session['ques_no'] = 1
        
    # # #print("question_timer:",session['ques_timer'])
    # # #print("question time division mode:",session['q_time_division'])
    return render_template('add_question.html',msg = "",option=1,ques=session['ques_no'])

@quiz.route('/add_question/',methods=['POST'])
@login_required
def add_questions():
    
    # session.pop('ques_no', None)
    # #print(session)
    if not session.get("ques_no") is None:
        print('')
        # #print("ques_no in add question:"+str(session['ques_no']))
        # if session['ques_no']!=1:
        #     session['ques_no'] = int(session['ques_no'])+1
    else:
        session['ques_no'] = 1
    # #print("ques_no in add question2:"+str(session['ques_no']))
    ques_no = str(session['ques_no'])
    # #print(type(ques_no))
    ques = request.form['ques'+ques_no]
    pts = request.form['points']
    ans_type = request.form['answ_type']
    if session['ques_timer']==1 and session['q_time_division']=='m':
        if ans_type == 'mcq':
            mins = int(request.form['mcq_mins'])
            secs = int(request.form['mcq_secs'])
        elif ans_type =='one_line':
            mins = int(request.form['one_mins'])
            secs = int(request.form['one_secs'])
        elif ans_type == 'descriptive':
            mins = int(request.form['desc_mins'])
            secs = int(request.form['desc_secs'])

        # #print("Mins:",mins)
        # #print("Secs:",secs)
            
        hour = 0
        ques_time = "%d:%02d:%02d" % (hour, mins, secs) 
         
    else:
        ques_time = ''
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    if ans_type=='mcq':
        ans_type = 0
        ttloptions = int(request.form['ttloptions'])
        correct_option = request.form['correct_opt']
        options= list()
        # #print(ttloptions)
        # # #print(request.form["opt"+ques_no])
        for i in range(1,5):
            # #print("I value:"+str(i))#
            j = "opt"+str(i) 
            if j in request.form:
                options.append(request.form["opt"+str(i)])
            else:
                # #print("Value Not present")
                options.append("-")

        result = cur.execute("INSERT INTO questions (q_no,question,ans_type,opt1,opt2,opt3,opt4,correct_opt,q_time,points,quiz_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(ques_no,ques,ans_type,options[0],options[1],options[2],options[3],correct_option,ques_time,pts,session["quiz_id"]))
    elif ans_type=='one_line':
        ans_type = 1
        result = cur.execute("INSERT INTO questions (q_no,question,ans_type,q_time,points,quiz_id) VALUES (%s,%s,%s,%s,%s,%s)",(ques_no,ques,ans_type,ques_time,pts,session["quiz_id"]))
    elif ans_type == 'descriptive':
        ans_type = 2
        result = cur.execute("INSERT INTO questions (q_no,question,ans_type,q_time,points,quiz_id) VALUES (%s,%s,%s,%s,%s,%s)",(ques_no,ques,ans_type,ques_time,pts,session["quiz_id"]))
    
    # questions = {
    # 'question': ques,
    # 'total_options': ttloptions,
    # 'options':options,
    # 'correct_option':correct_option
    # }
 
    mysql.connection.commit()

    session['ques_no'] = int(session['ques_no'])+1
    # session['total_questions'] = total_questions
    # # #print(questions)
    # # #print(total_questions)
    # # #print("Size of Session:"+str(sys.getsizeof(session)))
    return redirect(url_for('quiz.add_quiz_details'))
    # return render_template('add_question.html',msg = "",ques=ques_no)

@quiz.route('/cancel_quiz/',methods=['POST', 'GET'])
@login_required
def quiz_cancel():
    if not session.get("quiz_id") is None:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        result = cur.execute("DELETE FROM quiz_det WHERE quiz_id = %s",[session['quiz_id']])    
        mysql.connection.commit()
        session.pop("quiz_id",None)
        session.pop("ques_no",None)
    return redirect(url_for('dashboard'))

@quiz.route('/complete_quiz/',methods=['POST', 'GET'])
@login_required
def quiz_completion():
    if session.get("quiz_id") is not None:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        result = result = cur.execute("UPDATE quiz_det SET quiz_status = 1 WHERE quiz_id = %s" ,[session['quiz_id']])
        mysql.connection.commit()
        session.pop("quiz_id",None)
        session.pop("ques_no",None)
    return redirect(url_for('dashboard'))

@quiz.route('/cancel_quiz_quest/',methods=['POST', 'GET'])
@login_required
def quiz_cancel_quest():
    if session.get("quiz_id") is not None and session.get("ques_no") is not None:
        # #print("exists")
        # #print("Quiz ID:"+session['quiz_id'])
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("DELETE FROM quiz_det WHERE quiz_id = %s",[session['quiz_id']])    
        mysql.connection.commit()
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("DELETE FROM questions WHERE quiz_id = %s",[session['quiz_id']])    
        mysql.connection.commit()
        session.pop("quiz_id",None)
        session.pop("ques_no",None)
    else:
        print('')
        # #print("Not Exists!")
    return redirect(url_for('dashboard'))

@quiz.route('/start_quiz',methods=['POST','GET'])
@login_required
def quiz_start():
    qid = request.args.get('quiz_id')
    return render_template('/start_quiz.html',qid=qid)

@quiz.route('/get_quiz', methods=['POST', 'GET'])
@login_required
def quiz_get():
    qt = request.args.get('quiz_id')
    session['quiz_id'] = qt
    mode = session['mode']    
    if mode=="Faculty":
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT COUNT(q_no) AS total_question FROM questions WHERE quiz_id = %s",[qt])
        record = cur.fetchone()
        # #print(record)
        if record:
            session['ques_no'] = int(record['total_question'])+1
        cur.execute("SELECT * FROM quiz_det WHERE quiz_id = %s",[session['quiz_id']])
        quiz = cur.fetchone()
        db_date = datetime.datetime.strptime(quiz['q_date'], '%Y-%m-%d').date()
        dt1 = datetime.datetime.strptime(datetime.datetime.today().strftime('%Y-%m-%d'), '%Y-%m-%d').date()
        today_time = datetime.datetime.now(IST).strftime('%H:%M')
        st=datetime.datetime.strptime(quiz['q_time_start'],'%H:%M').time()
        t_time=datetime.datetime.strptime(today_time,'%H:%M').time()
        session['ques_timer']=quiz['q_timer']
        session['q_time_division']=quiz['q_time_division']
        # #print(db_date)
        # #print(dt1)
        # #print(t_time)
        # #print(st)
        
        # if dt1 < db_date or (dt1 == db_date and t_time<st):
        #     return redirect(url_for('quiz_preview'))
        # else:
        #     session['overtime'] = 1
        #     return redirect(url_for('dashboard'))
        return redirect(url_for('quiz.quiz_preview'))
    elif mode=="Student":
        if session.get('switch') is not None:
            session.pop('switch',None)
        if session.get('attempt_ques') is not None:
            session.pop('attempt_ques',None)
        return redirect(url_for('student.student_quiz'))

@quiz.route('/preview_quiz/',methods=['POST', 'GET'])
@login_required
def quiz_preview():
    # #print(session)
    if session.get("quiz_id") is not None:
        # # #print("exists")
        # #print("Quiz ID:"+session['quiz_id'])
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM quiz_det WHERE quiz_id = %s",[session['quiz_id']])
        quiz = cur.fetchone()
        if len(quiz['q_time_start']) == 5:
            quiz_start_time = quiz['q_time_start']+':00'
        else:
            quiz_stop_time = quiz['q_time_start']
        quiz_start_time = datetime.datetime.strptime(quiz_start_time, '%H:%M:%S')
        quiz_start_time_pre = quiz_start_time - datetime.timedelta(minutes = 10)
        quiz_start_time_pre = quiz_start_time_pre.strftime('%H:%M:%S')
        quiz_start_time_pre = datetime.datetime.strptime(quiz_start_time_pre, '%H:%M:%S').time()
        print("Quiz start pre time:",quiz_start_time_pre)
        now_time = datetime.datetime.now(IST).strftime('%H:%M:%S')
        now_time = datetime.datetime.strptime(now_time,'%H:%M:%S').time()
        dt1 = datetime.datetime.strptime(datetime.datetime.now(IST).strftime('%Y-%m-%d'), '%Y-%m-%d').date()
        db_date = datetime.datetime.strptime(quiz['q_date'], '%Y-%m-%d').date()
        perm_start = 0
        if quiz['quiz_started']==0 and now_time >= quiz_start_time_pre and dt1 == db_date:
            print("Now time greater than stop time")
            perm_start = 1
        elif now_time < quiz_start_time_pre:
            print("Now time greater than stop time")
        # #print("Found QUiz:")
        # #print(quiz)
        cur.close()
        dept =  quiz['q_dept']
        sem = 'sem'+quiz['q_sem']
        # #print(dept)
        # #print(sem)
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT \
            subject.subject_name AS s_name \
            FROM subject \
            INNER JOIN department ON subject.dept_id = department.dept_id \
            WHERE department.dept_short = %s AND subject.sem = %s', (dept,sem,))
        records = cursor.fetchall()
        # #print(records)
        subjects = list()    
        for row in records:
            subjects.append(row['s_name'])
        cursor.close()
        return render_template('preview_quiz.html',msg = "",quiz_det = quiz,sub = subjects,permission_to_start=perm_start)
    else:
        return render_template('preview_quiz.html',msg = "Quiz Not Created Yet!")

@quiz.route('/preview_quiz_question/',methods=['POST', 'GET'])
@login_required
def quiz_preview_question():
    # #print(session)
    if session.get("ques_no") is not None and session.get("ques_no")!=1:
        # # #print("exists")
        # #print("Quiz ID:"+session['quiz_id'])
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        if session['ques_timer']==1 and session['q_time_division']=='eq':
            cur.execute("SELECT q_time_start,q_time_end FROM quiz_det WHERE quiz_id = %s",[session['quiz_id']])
            result = cur.fetchone()
            q_time_start = result['q_time_start']
            q_time_end = result['q_time_end']
            cur.execute("SELECT COUNT(question) AS ques_len FROM questions WHERE quiz_id = %s",[session['quiz_id']])
            result = cur.fetchone()
            ttl_ques = result['ques_len']
            ttl_ques = int(ttl_ques)
            FMT = '%H:%M'
            delta = datetime.datetime.strptime(q_time_end, FMT) - datetime.datetime.strptime(q_time_start, FMT)
            time_diff = delta.seconds/60
            # #print("The time difference is :",time_diff)
            diff = time_diff / ttl_ques
            t_per_question = datetime.timedelta(minutes = diff)
            time_per_question = (datetime.datetime.min + t_per_question).time()
            # time_per_question = str(t_per_question).strftime('%H:%M:%S')
            # #print("The time per question is :",time_per_question)
            result = cur.execute("UPDATE questions SET q_time = %s  WHERE quiz_id = %s" ,(time_per_question,session['quiz_id']))
            mysql.connection.commit()

        cur.execute("SELECT * FROM questions WHERE quiz_id = %s",[session['quiz_id']])
        records = cur.fetchall()
        questions = list()
        mode = 0
        for row in records:
            questions.append(row)
        # #print(questions)
        cur.close()
        return render_template('preview_quiz_ques.html',msg = "",ques=questions,len = len(questions),ques_no=1)
    else:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT q_timer,q_time_division FROM quiz_det WHERE quiz_id = %s",[session['quiz_id']])
        records = cur.fetchone()
        session['ques_timer'] = records['q_timer']
        if records['q_time_division']!='-':
            session['q_time_division'] = records['q_time_division']
            # #print(session['q_time_division'])
        # #print(session['quiz_id'])
        # #print(session['ques_timer'])
        # # #print("Time per Question:",session['q_time_division'])
        cur.close()
        return render_template('preview_quiz_ques.html',msg = "No Questions Added Yet!")


@quiz.route('/edit_quiz_quest',methods=['POST','GET'])
@login_required
def edit_question():
    qt = request.args.get('q')
    # #print(type(qt))
    # if request.method == 'POST':
    q_id =  request.form.get('question_no'+qt)
    # #print(request.form.get('question_no'+qt))
    # # #print("got this shit:"+q_id)
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM questions WHERE q_id = %s AND quiz_id = %s",(q_id,session['quiz_id']))
    question = cur.fetchone()
    if question:
        msg = 'Got data successfully !'
        cur.close()
        # ed_ques = list(question)
        # # #print(ed_ques)
        # for row in question:
        #     ed_ques.append(row)
        return render_template('edit_quiz.html',msg = "",ques_det=question,ques_no=qt)
    return render_template('edit_quiz.html',msg = "",ques_det=question,ques_no=qt)
    # else:
    #     cur.close()
    #     msg="Could not Edit the question!"
    #     return redirect(url_for('quiz_preview'))        

@quiz.route('/update_question/',methods=['POST'])
@login_required
def update_questions():
    q_no = request.form['ques_no'];
    ques = request.form['ques'+q_no];
    pts = request.form['ed_points']
    ans_type = request.form['ed_answ_type']
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    q_index = request.form['ques_index'];

    if ans_type=='mcq':
        ans_type = 0
        correct_option = request.form['correct_opt'];
        ttloptions = int(request.form['ttloptions'])
        options= list()
        if session['ques_timer']==1 and session['q_time_division']=='m':
            mins = int(request.form['ed_mcq_mins'])
            secs = int(request.form['ed_mcq_secs'])
            # #print("Mins:",mins)
            # #print("Secs:",secs)
            hour = 0
            ques_time = "%d:%02d:%02d" % (hour, mins, secs) 
             
        else:
            ques_time = ''


        for i in range(1,5):
            # # #print("I value:"+str(i))#
            j = "opt"+str(i) 
            if j in request.form:
                options.append(request.form["opt"+str(i)])
            else:
                # #print("Value Not present")
                options.append("-")
        result = cur.execute("UPDATE questions SET question = %s , opt1  = %s , opt2 = %s , opt3 = %s , opt4 = %s , correct_opt = %s , ans_type = %s , points = %s, q_time = %s WHERE q_id = %s" ,(ques,options[0],options[1],options[2],options[3],correct_option,ans_type,pts,ques_time,q_index))
    elif ans_type=='one_line' or ans_type=='desc':
        if ans_type=='one_line':
            ans_type = 1
        elif ans_type=='desc':
            ans_type = 2

        if session['ques_timer']==1 and session['q_time_division']=='m':
            mins = int(request.form['ed_one_mins'])
            secs = int(request.form['ed_one_secs'])
            # #print("Mins:",mins)
            # #print("Secs:",secs)
            hour = 0
            ques_time = "%d:%02d:%02d" % (hour, mins, secs) 
             
        else:
            ques_time = ''
        # #print("Question Time:",ques_time)
        result = cur.execute("UPDATE questions SET question = %s , opt1  = '-' , opt2 = '-' , opt3 = '-' , opt4 = '-' , correct_opt = '-' , ans_type = %s , points = %s, q_time = %s WHERE q_id = %s" ,(ques,ans_type,pts,ques_time,q_index))    

    mysql.connection.commit()
    return redirect(url_for('quiz.quiz_preview_question'))

@quiz.route('/update_quiz_det/',methods=['POST'])
@login_required
def quiz_update_details():
    title =  request.form['quiz_title'];
    dept =  request.form['dept'];
    sem =  request.form['sem'];
    quiz_type = request.form['quiz_type'];
    if quiz_type=='1':
        sub = ''
    else:
        sub =  request.form['sub'];
    batch =  request.form['batch'];
    date =  request.form['date'];
    s_time =  request.form['s_time'];
    e_time =  request.form['e_time'];
    view_score =  request.form['view_score'];
    ques_timer =  request.form['up_ques_timer'];
    switch_limit =  request.form['switch_limit']
    desc_time =  request.form['desc_time']
    # #print('Ques Time:',ques_timer)

    if view_score=='Yes':
        view_score = 1
        
    else:
        view_score = 0

    if ques_timer=='Yes':
        ques_timer = 1
        q_time_divide =  request.form['up_q_time_divide'];

    else:
        ques_timer = 0
        q_time_divide = '-'

    # #print('sub',sub)
    # #print('quiz_type',quiz_type)

    session['q_time_division'] = q_time_divide
    session['ques_timer'] = ques_timer

    q_index = request.form['quiz_index'];
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    result = cur.execute("UPDATE quiz_det SET q_title = %s ,q_dept = %s ,q_sem = %s ,q_sub = %s ,q_batch = %s ,q_date = %s ,q_time_start = %s ,q_time_end = %s ,show_answer= %s,q_timer=%s,q_time_division=%s,quiz_type=%s,switch_limit=%s,desc_time=%s WHERE quiz_id = %s" ,(title,dept,sem,sub,batch,date,s_time,e_time,view_score,ques_timer,q_time_divide,quiz_type,switch_limit,desc_time,q_index))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('quiz.quiz_preview_question'))

@quiz.route('/del_question/',methods=['POST'])
@login_required
def question_delete():
    # #print(session)
    q_index = request.form['index'];
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("DELETE FROM questions WHERE q_id = %s",[q_index])
    mysql.connection.commit()
    session['ques_no'] = int(session['ques_no'])-1
    return json.dumps("Deleted successfully");

@quiz.route('/del_quiz/',methods=['POST'])
@login_required
def quiz_delete():
    #print(session)
    q_index = request.form['index']
    # #print("exists")
    #print("Quiz ID:"+session['quiz_id'])
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("DELETE FROM quiz_responses WHERE quiz_id = %s",[session['quiz_id']])    
    mysql.connection.commit()
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("DELETE FROM score WHERE quiz_id = %s",[session['quiz_id']])    
    mysql.connection.commit()
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("DELETE FROM quiz_det WHERE quiz_id = %s",[session['quiz_id']])    
    mysql.connection.commit()
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("DELETE FROM questions WHERE quiz_id = %s",[session['quiz_id']])    
    mysql.connection.commit()
    
    # cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    # cur.execute("DELETE t1, t2, t3, t4 FROM \
    #       score as t1 \
    #       INNER JOIN  quiz_responses as t2 on t1.quiz_id = t2.quiz_id \
    #       INNER JOIN  questions as t3 on t1.quiz_id=t3.quiz_id \
    #       INNER JOIN  quiz_det as t4 on t1.quiz_id=t4.quiz_id \
    #       WHERE  t1.quiz_id = %s",[session['quiz_id']])    
    # mysql.connection.commit()
    session.pop("quiz_id",None)
    session.pop("ques_no",None)
    # #print("Not Exists!")
    session['message'] = 'Quiz Deleted Successfully!'
    return redirect(url_for('quiz.quizes_all'))
    # return json.dumps("Deleted successfully");

@quiz.route('/get_response', methods=['POST', 'GET'])
@login_required
def responses_get():
    qt = request.args.get('quiz_id')
    session['quiz_id'] = qt
    mode = session['mode']    
    if mode=="Faculty":
        return redirect(url_for('quiz.response'))
    elif mode=="Student":
        session['over_access'] = 1
        return redirect(url_for('dashboard'))

@quiz.route('/show_responses/')
@login_required
def response():
    if session.get('quiz_id') is not None:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT COUNT(user) AS user_attempt FROM score WHERE quiz_id =%s AND quiz_attempted=1', [session['quiz_id']])
        records = cursor.fetchone()
        # #print(records)
        if records['user_attempt'] is not None or records['user_attempt'] != 0:
            user_quiz_attempt = records['user_attempt']
            cursor.execute('SELECT user_score,total_points FROM score WHERE quiz_id =%s AND quiz_attempted=1', [session['quiz_id']])
            rd = cursor.fetchall()
            cursor.close()
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute('SELECT SUM(points) AS total_points FROM questions WHERE quiz_id =%s', [session['quiz_id']])
            total_pts = cursor.fetchone()
            total_points = total_pts['total_points']
            cursor.close()
            # #print(rd)
            stud_correct_opt = list()
            for row in rd:
                # #print("present")
                # #print(row)
                percent = round((int(row['user_score']) / int(row['total_points']))*100,0)
                # #print(percent)
                stud_correct_opt.append(percent)  
            # #print(stud_correct_opt)
            if len(stud_correct_opt)!=0:
                avg_right = sum(stud_correct_opt) / len(stud_correct_opt)
            else:
                avg_right = ""
            # #print("Average Right:")
            # #print(avg_right)
            
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute('SELECT q_date,q_time_start,q_sub,q_title,q_sem,q_dept,q_batch,quiz_start FROM quiz_det,quiz_responses WHERE quiz_det.quiz_id = %s', [session['quiz_id']])
            r_quiz = cursor.fetchone()

            # #print(r_quiz)
            if r_quiz is not None:
            
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                if r_quiz['q_batch']=="All":
                    cursor.execute('SELECT COUNT(S_id) AS total_stud FROM student WHERE current_sem =%s AND dept= %s', (r_quiz['q_sem'],r_quiz['q_dept']))
                else:
                    cursor.execute('SELECT COUNT(S_id) AS total_stud FROM student WHERE current_sem =%s AND dept= %s AND batch=%s', (r_quiz['q_sem'],r_quiz['q_dept'],r_quiz['q_batch']))
                quiz_responses = cursor.fetchone()
                quiz_responses = {'total_stud': 72}
                print(quiz_responses)
                cursor.close()
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                cursor.execute('SELECT username,roll,stud_img,user_score,total_points,total_time_taken FROM score WHERE quiz_id =%s ORDER BY user_score DESC,total_time_taken ASC  LIMIT 5', [session['quiz_id']])
                records = cursor.fetchall()
                cursor.close()
                rankers = list()
                for row in records:
                    if row['stud_img']=="":
                        row['stud_img'] = 'images/man.png'
                    rankers.append(row)
                total_points = int(total_points)
                cursor.close()
                
                # for row in records:
                #     if row['image']=="":
                #         if row['gender']=='M':
                #             row['image'] = 'images/man.png'
                #         elif row['gender'] == 'F':
                #             row['image'] = 'images/woman.png'
                    # if row['time_submitted'] !='':
                    #     time_submit = datetime.datetime.strptime(row['time_submitted'], '%H:%M:%S')
                    # else:
                    #     time_submit = datetime.datetime.strptime('00:00:00', '%H:%M:%S')
                    # # #print(r_quiz['quiz_start'])
                    # if r_quiz['quiz_start']!='' and r_quiz['quiz_start'] is not None:
                    #     quiz_time = datetime.datetime.strptime(r_quiz['quiz_start'], '%H:%M:%S')
                    # else:
                    #     quiz_time = datetime.datetime.strptime('00:00:00', '%H:%M:%S')   
                    # # #print(time_submit)
                    # # #print(quiz_time)
                    # row['time_submitted'] = (time_submit - quiz_time)
                    # # #print(row['time_submitted'])
                    # rankers.append(row)
                return render_template('response.html',avg_correct=avg_right,qz_rsp=user_quiz_attempt,total_stud=quiz_responses['total_stud'],quiz_name=r_quiz['q_title'],quiz_sub=r_quiz['q_sub'],toppers=rankers,tplen= len(rankers),total_points=total_points)
            else:
                cursor.execute('SELECT q_sub,q_title,q_sem,q_dept,q_batch FROM quiz_det WHERE quiz_id =%s', [session['quiz_id']])
                r_quiz = cursor.fetchone()
                cursor.close()
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                if r_quiz['q_batch']=="All":
                    cursor.execute('SELECT COUNT(S_id) AS total_stud FROM student WHERE current_sem =%s AND dept= %s', (r_quiz['q_sem'],r_quiz['q_dept']))
                else:
                    cursor.execute('SELECT COUNT(S_id) AS total_stud FROM student WHERE current_sem =%s AND dept= %s AND batch=%s', (r_quiz['q_sem'],r_quiz['q_dept'],r_quiz['q_batch']))
                quiz_responses = cursor.fetchone()
                cursor.close()
                return render_template('response.html',avg_correct="",qz_rsp=0,total_stud=quiz_responses['total_stud'],quiz_name=r_quiz['q_title'],quiz_sub=r_quiz['q_sub'],toppers=0,tplen=0)

    else:
        return redirect(url_for('quiz.quizes_all'))

@quiz.route('/show_graph_value', methods=['POST', 'GET'])
@login_required
def graph_response():
    label = request.args.get('label')
    if label=='Quiz Attempted in %:' :
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT q_date,q_time_end,q_time_start,q_sub,q_title,q_sem,q_dept,q_batch,show_answer,quiz_started FROM quiz_det WHERE quiz_id =%s',[session['quiz_id']])
        r_quiz = cursor.fetchone()
        # #print("quiz_det",r_quiz)
        if r_quiz['q_batch']=="All":
            # cursor.execute('SELECT user,time_submitted,username,roll,stud_img,user_score,total_points,pending_chk,total_time_taken FROM score WHERE quiz_id =%s ORDER BY user_score DESC,time_submitted ASC', [session['quiz_id']])
            cursor.execute('SELECT user,time_submitted,username,roll,stud_img,user_score,total_points,pending_chk,total_time_taken FROM score WHERE quiz_id =%s ORDER BY roll ASC', [session['quiz_id']])
        else:
            # cursor.execute('SELECT user,time_submitted,username,roll,stud_img,user_score,total_points,pending_chk,total_time_taken FROM score WHERE quiz_id =%s ORDER BY user_score DESC,time_submitted ASC', [session['quiz_id']]) 
            cursor.execute('SELECT user,time_submitted,username,roll,stud_img,user_score,total_points,pending_chk,total_time_taken FROM score WHERE quiz_id =%s ORDER BY roll ASC', [session['quiz_id']]) 
        records = cursor.fetchall()
        cursor.execute('SELECT quiz_start FROM quiz_responses WHERE quiz_id = %s', [session['quiz_id']])
        r2_quiz = cursor.fetchone()
        # #print("Quiz Start:",r2_quiz)
        # #print("Quiz Start Type:",type(r2_quiz))
        students_attempt = list()
        pending_chk = 0
        chk = 0
        for row in records:
            # #print(row)
            if row['pending_chk']==1 and chk==0:
                pending_chk = 1
                chk=1
            if row['time_submitted'] is None and r2_quiz is None:
                row['time_submitted'] = '00:00:00'
                r2_quiz = {}
                r2_quiz['quiz_start'] = '00:00:00'
            elif row['time_submitted'] is None:
                row['time_submitted'] = '00:00:00'
            elif r2_quiz is None or r2_quiz['quiz_start'] is None :
                r2_quiz = {}
                r_quiz['q_time_start'] = r_quiz['q_time_start']+':00'
                r2_quiz['quiz_start'] = datetime.datetime.strptime(r_quiz['q_time_start'], '%H:%M:%S')
                r2_quiz['quiz_start'] = r2_quiz['quiz_start'].strftime('%H:%M:%S')
            # #print("R2 quiz",r2_quiz)
            # #print("The time started:",row['time_submitted'])
            row['time_submitted'] = datetime.datetime.strptime(row['time_submitted'], '%H:%M:%S') - datetime.datetime.strptime(r2_quiz['quiz_start'], '%H:%M:%S')
            # row['time_submitted'] = row['total_time_taken']
            students_attempt.append(row)
        cursor.close()
        # #print("pending_chk:",pending_chk)
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT SUM(points) AS total_points FROM questions WHERE quiz_id =%s', [session['quiz_id']])
        total_pts = cursor.fetchone()
        total_pts['total_points'] = int(total_pts['total_points'])
        if len(r_quiz['q_time_end']) == 5:
            quiz_stop_time = r_quiz['q_time_end']+':00'
        else:
            quiz_stop_time = r_quiz['q_time_end']
        quiz_stop_time = datetime.datetime.strptime(quiz_stop_time, '%H:%M:%S')
        quiz_stop_time_post = quiz_stop_time + datetime.timedelta(minutes = 30)
        quiz_stop_time_post = quiz_stop_time_post.strftime('%H:%M:%S')
        quiz_stop_time_post = datetime.datetime.strptime(quiz_stop_time_post, '%H:%M:%S').time()
        print("Quiz stop post time:",quiz_stop_time_post)
        now_time = datetime.datetime.now(IST).strftime('%H:%M:%S')
        now_time = datetime.datetime.strptime(now_time,'%H:%M:%S').time()
        dt1 = datetime.datetime.strptime(datetime.datetime.now(IST).strftime('%Y-%m-%d'), '%Y-%m-%d').date()
        db_date = datetime.datetime.strptime(r_quiz['q_date'], '%Y-%m-%d').date()
        perm_stop = 0
        if r_quiz['quiz_started']==1 and now_time < quiz_stop_time_post and dt1 == db_date:
            print("Now time lesser than stop time")
            perm_stop = 1
        elif now_time > quiz_stop_time_post:
            print("Now time greater than stop time")
        return render_template('response_graph.html',label="Student's Submitted Quiz",quiz_name=r_quiz['q_title'],quiz_sub=r_quiz['q_sub'],toppers=students_attempt,tplen= len(students_attempt),notattempt=0,check=pending_chk,total_points=total_pts['total_points'],show_answer=r_quiz['show_answer'],quiz_started=r_quiz['quiz_started'],permission_to_stop=perm_stop)
    elif label=='Quiz Not Attempted in %:':
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT q_sub,q_title,q_sem,q_dept,q_batch FROM quiz_det WHERE quiz_id =%s', [session['quiz_id']])
        r_quiz = cursor.fetchone()
        cursor.close()
        # #print("quiz_det",r_quiz)
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT COUNT(user) AS total_responses FROM score WHERE quiz_id =%s ', [session['quiz_id']])
        records = cursor.fetchone()
        cursor.close()
        if session.get('strength') is None:
            semester = r_quiz['q_sem']
            subject = r_quiz['q_sub']
            dept = r_quiz['q_dept']
            url = 'https://www.kjsieit.in/sims/php/studentdata.php'
            sem_bytes = semester.encode("ascii")
            base64_sem = base64.b64encode(sem_bytes)
            subject_bytes = subject.encode("ascii")
            base64_subject = base64.b64encode(subject_bytes)
            dept_bytes = dept.encode("ascii")
            base64_dept = base64.b64encode(dept_bytes)
            code_bytes = code.encode("ascii")
            base64_code = base64.b64encode(code_bytes)
            pload = {"branch":base64_dept,"sem":base64_sem,"elective":base64_subject,"code":base64_code}
            # # #print(pload)
            r = requests.post(url,data = pload)
            # # #print(r.text)
            jsonResponse = json.loads(r.text)
            # #print(jsonResponse)
            total_students = int(jsonResponse['strength'])
        else:
            total_students = session['strength']
        responses_left = total_students - records['total_responses']

        message = ''        
        color = -1
        if session.get('message') is not None and session.get('message_color') is not None:
            message = session['message']
            if session['message_color']==1:
                color = session['message_color']

        return render_template('response_graph.html',msg=message,msg_color=color,label="Student's Not Submitted Quiz",quiz_name=r_quiz['q_title'],quiz_sub=r_quiz['q_sub'],rsp_left=responses_left,tplen= total_students,notattempt=1)
    else:
        return Response("Page Doesnt Exists!",status=400,)

@quiz.route('/start_stop_quiz/',methods=['POST'])
@login_required
def start_stop_quiz_status():
    start_stop = int(request.form['start'])
    if start_stop == 0 or start_stop == 1:
        # start - 1 , stop- 0
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("UPDATE quiz_det SET quiz_started = %s WHERE quiz_id = %s AND fac_inserted=%s" ,(start_stop,session['quiz_id'],session['svv']))    
        mysql.connection.commit()
        cur.close()
        return json.dumps(1)
    else:
        return json.dumps(0)

@quiz.route('/release_score/',methods=['POST', 'GET'])
@login_required
def score_release():
    # #print('session',session)
    if request.form['send_value'] is not None:
        quiz_id = str(request.form['send_value'])
        # #print(quiz_id)
        # #print(type(quiz_id))
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("UPDATE quiz_det SET show_answer = %s WHERE quiz_id = %s AND fac_inserted=%s" ,(1,quiz_id,session['svv']))    
        mysql.connection.commit()
        cur.close()
        session['message'] = 'Successfully Marked!'
        session['message_color'] = 1
        return redirect('/quiz/show_graph_value?label=Quiz Attempted in %:')
    else:
        session['message'] = 'Session Destroyed , Go to Dashboard'
        session['message_color'] = 1
        return redirect('/quiz/show_graph_value?label=Quiz Attempted in %:')

@quiz.route('/check_answer/',methods=['POST', 'GET'])
@login_required
def mark_answer():
    stud_id = request.form['send_value']
    # # #print(stud_id)
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT user,user_score,ques_points,pending_chk,total_points FROM score WHERE user = %s AND quiz_id = %s",(stud_id,session['quiz_id']))
    student = cur.fetchone()
    cur.close()
    # #print(student)
    # #print(student['ques_points'])
    if student['ques_points'] != '':
        ques_points = student['ques_points'].split(",")
    else:
        ques_points = [0]
    #print("Question Points:",ques_points)
    score = list(map(float, ques_points))
    score = sum(score)
    # #print("Score:",score)
    total_score = {}
    total_score['score'] = int(math.ceil(score))
    total_score['total_points'] = student['total_points']
    # #print("Total Points:",total_score['total_points'])
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT F_name,L_name,roll FROM student WHERE S_id = %s",[student['user']])
    stud_info = cur.fetchone()
    cur.close()
    # #print(session)
    if student is not None:
        # # #print("exists")
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM questions WHERE quiz_id = %s",[session['quiz_id']])
        records = cur.fetchall()
        questions = list()
        question_index = list()
        for row in records:
            questions.append(row)
            if row['ans_type']==1:
                question_index.append(str(row['q_id']))
        # #print(questions[0]['q_id'])
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT selected_opt,ques_id,ques_type,one_line_ans,desc_ans_name,time_per_ques FROM quiz_responses WHERE quiz_id = %s AND user_inserted=%s",(session['quiz_id'],stud_id))
        quiz_response = cur.fetchone()
        # # #print(type(quiz_response))
        cur.close()

        if quiz_response is not None:
            ques_index = quiz_response['ques_id'].split(",")
            if quiz_response['one_line_ans'] is not None:
                res_one_line = quiz_response['one_line_ans'].split("$,")
            else:
                res_one_line = []
            if quiz_response['ques_id'] is not None:
                ques_index = quiz_response['ques_id'].split(",")
            else:
                ques_index = []
            if quiz_response['selected_opt'] is not None:
                res_select_opt_mcq = quiz_response['selected_opt'].split(",")
            else:
                res_select_opt_mcq = []
            if quiz_response['desc_ans_name'] is not None:
                res_select_desc_ans = quiz_response['desc_ans_name'].split(",")
            else:   
                res_select_desc_ans = []

            ques_type = quiz_response['ques_type'].split(",")
            time_per_ques = quiz_response['time_per_ques'].split(",")
            copy = 0
        else:
            ques_index = question_index
            res_one_line = []
            res_select_opt_mcq = []
            res_select_desc_ans = []
            ques_type = []
            time_per_ques = []
            copy = 1

        
        answers = list()
        mcq_ct = 0
        one_line_ct = 0
        desc_ans_ct = 0
        # #print(ques_type)
        # #print(ques_index)
        # #print(res_one_line)
        # #print(res_select_opt_mcq)
        if len(ques_type)>0:
            for i in range(len(ques_type)):
                if ques_type[i] == '0':
                    answers.append(res_select_opt_mcq[mcq_ct])
                    mcq_ct += 1
                elif ques_type[i] == '1':
                    answers.append(res_one_line[one_line_ct])
                    one_line_ct += 1
                elif ques_type[i] == '2':
                    answers.append(res_select_desc_ans[desc_ans_ct])
                    desc_ans_ct += 1
                
        else:
            answers = []
        #print("Answers:",answers)
        op = list()
        for i in range(len(questions)):
            #print("I:",i," type is :",type(i))
            op1 = {}
            op1['ques'] = questions[i]['question']
            op1['point'] = questions[i]['points']
            op1['ans_type'] = questions[i]['ans_type']
            op1['opt1'] = questions[i]['opt1']
            op1['opt2'] = questions[i]['opt2']
            op1['opt3'] = questions[i]['opt3']
            op1['opt4'] = questions[i]['opt4']
            op1['correct_opt'] = questions[i]['correct_opt']
            #print('ques_index',ques_index)
            if str(questions[i]['q_id']) in ques_index :
                index = ques_index.index(str(questions[i]['q_id']))
                #print("index:",index)
                if quiz_response is not None:
                    op1['answered'] = answers[index]
                    op1['got_point'] = ques_points[index]
                    op1['time_per_ques'] = time_per_ques[index]
                else:
                    op1['answered'] = ''
                    op1['got_point'] = ques_points[index]
                    op1['time_per_ques'] = ''
            else:
                op1['answered'] = ""
                op1['got_point'] = "0"
                op1['time_per_ques'] = "00:00:00"
            #print('op1',op1)
            #print(op)
            op.append(op1)
        #print(op)
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT SUM(points) AS total_points FROM questions WHERE quiz_id =%s', [session['quiz_id']])
        total_pts = cursor.fetchone()
        total_pts['total_points'] = int(total_pts['total_points'])
        return render_template('mark_answer.html',msg = "",ques=op,len = len(questions),ques_no=1,checked=student['pending_chk'],stud=stud_info,score=total_score,student_id=stud_id,tried_copy=copy,total_points=total_pts['total_points'])
    else:
        return render_template('mark_answer.html',msg = "Not Attempted The Quiz!")

@quiz.route('/mark_student/',methods=['POST', 'GET'])
@login_required
def update_marks_student():
    stud_id = request.form['stud_id']
    # #print("STudent ID:",stud_id)
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT q_id,ans_type FROM questions WHERE quiz_id = %s",[session['quiz_id']])
    total_ques_one_line = cur.fetchall()
    cur.close()
    marks = list()
    ques_index = list()
    for i in range(len(total_ques_one_line)):
        if total_ques_one_line[i]['ans_type']==1:
            marks.append(request.form['ans'+str(i+1)])
            ques_index.append(str(total_ques_one_line[i]['q_id']))
    # #print("Marks got :",marks)
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT ques_id FROM quiz_responses WHERE quiz_id = %s AND user_inserted =%s ",(session['quiz_id'],stud_id))
    question_shuffle = cur.fetchone()
    cur.close()
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT ques_points FROM score WHERE quiz_id = %s AND user =%s AND quiz_attempted=1 AND (pending_chk=1 OR pending_chk=0)",(session['quiz_id'],stud_id))
    user_ques_points = cur.fetchone()
    cur.close()
    # #print(user_ques_points)
    if question_shuffle is not None:
        questions_id = question_shuffle['ques_id'].split(",")
    else:
        questions_id = ques_index
    # #print('questions_id',questions_id)
    if user_ques_points['ques_points']!='':
        points = user_ques_points['ques_points'].split(",")
    else:
        points = [0]
    # #print('points',points)
    # #print(total_ques_one_line)
    mcq_ct = 0
    # #print('user_ques_points',user_ques_points)
    if user_ques_points['ques_points']!='' or user_ques_points['ques_points'] is not None:
        for i in range(len(total_ques_one_line)):
            # #print(total_ques_one_line[i]['q_id'])
            if total_ques_one_line[i]['ans_type']==1:
                if str(total_ques_one_line[i]['q_id']) in questions_id :
                    q_ind = questions_id.index(str(total_ques_one_line[i]['q_id']))
                    # #print("Q_ind:",q_ind)
                    points[q_ind] = marks[mcq_ct]
                    mcq_ct += 1

            # #print(points)
        points = list(map(float, points))
        total_points = sum(points)
        total_points = int(math.ceil(total_points))
        # #print(total_points)
        # #print(points)
        str_usr_points = ['{:.1f}'.format(x) for x in points]
        # #print(str_usr_points)
        str_usr_points = ','.join(str_usr_points)
        # #print(str_usr_points)
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("UPDATE score SET ques_points = %s , user_score = %s , pending_chk  = 0 WHERE quiz_id = %s AND user=%s" ,(str_usr_points,total_points,session['quiz_id'],stud_id))    
        mysql.connection.commit()
        session['message'] = 'Successfully Marked!'
        session['message_color'] = 1
        return redirect('/quiz/show_graph_value?label=Quiz Attempted in %:')
    else:
        session['message'] = 'Failed to Marked!'
        session['message_color'] = 0
        return redirect(url_for('quiz.response')) 

@quiz.route('/del_response/',methods=['POST'])
@login_required
def response_delete():
    #print(session)
    q_index = request.form['index']
    # #print("exists")
    #print("Quiz ID:"+session['quiz_id'])
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("DELETE FROM quiz_responses WHERE quiz_id = %s",[session['quiz_id']])    
    mysql.connection.commit()
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("DELETE FROM score WHERE quiz_id = %s",[session['quiz_id']])    
    mysql.connection.commit()
    session.pop("quiz_id",None)
    session.pop("ques_no",None)
    # #print("Not Exists!")
    session['message'] = 'Quiz Deleted Successfully!'
    return redirect(url_for('quiz.quizes_all'))

