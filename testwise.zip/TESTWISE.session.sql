CREATE TABLE `department` (
  `dept_id` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dept_name` varchar(70) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dept_short` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dept_intake` int NOT NULL,
  `dept_seat_filled` int NOT NULL,
  `duration` int NOT NULL COMMENT 'Yrs',
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;