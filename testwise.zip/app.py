import os
from dotenv import load_dotenv
from flask import Flask, request, render_template, redirect, url_for, session, jsonify
import json
from flask_mysqldb import MySQL
import MySQLdb.cursors
from flask_oauthlib.client import OAuth
import gc
from datetime import date
import datetime
# from functools import wraps
import base64
import requests
import pytz

load_dotenv()

app = Flask(__name__)

app.config["SECRET_KEY"] = os.environ.get("APP_SECRET_KEY")
app.config['MYSQL_HOST'] = '127.0.0.1'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'quicky'
# app.config['MYSQL_HOST'] = 'http://examportal.kjsieit.in/'
# app.config['MYSQL_USER'] = 'exam_portal'
# app.config['MYSQL_PASSWORD'] = 'EXAMPORTAL'
# app.config['MYSQL_DB'] = 'kjsieitexamportal'
app.config['GOOGLE_ID'] = "940087145192-fsbm0se399b5o2fjo01n95p81mr77vv5.apps.googleusercontent.com"
app.config['GOOGLE_SECRET'] = "w8z2AkmdFE4GvVa8O9dZ60YP"




oauth = OAuth(app)
google = oauth.remote_app(
    'google',
    consumer_key=app.config.get('GOOGLE_ID'),
    consumer_secret=app.config.get('GOOGLE_SECRET'),
    request_token_params={
        'scope': 'email'
    },
    base_url='https://www.googleapis.com/oauth2/v1/',
    request_token_url=None,
    access_token_method='POST',
    access_token_url='https://accounts.google.com/o/oauth2/token',
    authorize_url='https://accounts.google.com/o/oauth2/auth',
)

mysql = MySQL(app)
app_root = app.root_path
IST = pytz.timezone('Asia/Kolkata')

@app.route("/")
def load():
    return redirect(url_for('show_login'))

################################## Login ##########################################

@app.route('/google_login/')
def login2():
    return google.authorize(callback=url_for('authorized', _external=True))
     

@app.route('/google_login/authorized')
def authorized():
    resp = google.authorized_response()
    if resp is None:
        return 'Access denied: reason=%s error=%s' % (
            request.args['error_reason'],
            request.args['error_description']
        )
    session['google_token'] = (resp['access_token'], '')
    me = google.get('userinfo')
    return redirect(url_for('show_login'))

@google.tokengetter
def get_google_oauth_token():
    return session.get('google_token')

@app.route('/login/')
def show_login():
    # #print(session)
    if session.get("login") is not None:
        if session['login'] != 0:
            return redirect(url_for('dashboard'))
    elif 'google_token' in session:
        me = google.get('userinfo')
        personal_data = jsonify({"data": me.data})
        response = me.data        
        # msg = verify_email(response['email'])
        msg=""
        # #print(msg)
        if msg=="0":
            return render_template("login.html",message="Email ID does not exists in the database!")
        else:
            return redirect(url_for('dashboard'))
        # return personal_data
    else:
        return render_template("login.html",message="")

# def login_required(f):
#     @wraps(f)
#     def decorated(*args, **kwargs):
#         # #print('decorated')
#         # #print(session)
#         if 'login' in session:
#             return f(*args, **kwargs)
#         else:
#             return redirect(url_for('show_login'))

#     return decorated

# @app.route('/form_login/', methods=['POST', 'GET'])
def login_sims_id():
    # #print(session)
    url = 'https://www.kjsieit.in/sims/php/studentlogin.php'
    dp_stud_url = 'https://www.kjsieit.in/sims/images/studentdp/'
    dp_fac_url = 'https://www.kjsieit.in/sims/images/facdp/'

    user = request.form['username']
    password = request.form['pass']
    user_bytes = user.encode("ascii")
    base64_user = base64.b64encode(user_bytes)
    pass_bytes = password.encode("ascii")
    base64_pass = base64.b64encode(pass_bytes)

    # #print(base64_user)
    # #print(base64_pass)
    pload = {"username":base64_user,"password":base64_pass}
    r = requests.post(url,data = pload)
    print(r)
    jsonResponse = json.loads(r.text)
    print(jsonResponse)
    if jsonResponse['code']==1:
        msg = 'Logged in successfully !'
        session.permanent = True
        if jsonResponse['mode']==1:
            session['username'] = jsonResponse['fname'] +" "+ jsonResponse['lname']
            session['fullname'] = jsonResponse['des']+" "+jsonResponse['fname'] +" "+ jsonResponse['mname'] +" "+ jsonResponse['lname']
            session['svv'] = jsonResponse['facid']
            session['gender'] = ''
            session['login'] = 1
            session['mode'] = "Faculty"
            session['login_mode'] = "SVV"
            session['img'] = dp_fac_url+jsonResponse['img']
            session['dept'] = jsonResponse['branch']
            session['num'] = jsonResponse['phone']
        elif jsonResponse['mode']==2:
            session['username'] = jsonResponse['fname'] +" "+ jsonResponse['lname']
            session['fullname'] = jsonResponse['fname'] +" "+ jsonResponse['mname'] +" "+ jsonResponse['lname']
            session['svv'] = jsonResponse['clgid']
            session['roll'] = jsonResponse['roll']
            session['batch'] = jsonResponse['batch']
            session['gender'] = ''
            session['login'] = 1
            session['mode'] = "Student"
            session['login_mode'] = "SVV"
            session['img'] = dp_stud_url+jsonResponse['img']
            session['dept'] = jsonResponse['branch']
            session['sem'] = jsonResponse['sem']
            session['ele1'] = jsonResponse['ele1']
            session['ele2'] = jsonResponse['ele2']
            session['num'] = jsonResponse['phone']
        return redirect(url_for('dashboard'))
    elif jsonResponse['code']==0:
        msg = 'Incorrect Credentials !'
    return render_template('login.html', message=msg)

@app.route('/google_signin/', methods=['POST', 'GET'])
def google_login():
    return render_template("google_login.html")

@app.route('/form_login/', methods=['POST', 'GET'])
def login():
    # #print(session)
    name1 = request.form['username']
    pwd = request.form['pass']
    passwd = pwd.encode()
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM faculty WHERE F_email = % s AND F_password = % s', (name1, pwd,))
    account = cursor.fetchone()
    # hashed = account['F_password']
    # if bcrypt.checkpw(passwd, hashed):
    #     # #print("match")
    # else:
    #     # #print("does not match")
    if account:
        msg = 'Logged in successfully !'
        cursor.close()
        session['username'] = account['F_name'] +" "+ account['L_name']
        session['svv'] = account['F_id']
        session['gender'] = account['gender']
        session['login'] = 1
        session['mode'] = "Faculty"
        session['login_mode'] = "SVV"
        if account['gender']=='F':
            session['img'] = "/static/images/woman.png"
        elif account['gender']=='M':
            session['img'] = "/static/images/man.png"
        else:
            session['img'] = "images/user.png"
        return redirect(url_for('dashboard'))
    else:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM student WHERE S_email = % s AND S_pass = % s', (name1, pwd,))
        student = cursor.fetchone()
        if student:
            msg = 'Logged in successfully !'
            cursor.close()            
            session['username'] = student['F_name'] +" "+ student['L_name']
            session['svv'] = student['S_id']
            session['gender'] = student['gender']
            session['dept'] = student['dept']
            session['sem'] = student['current_sem']
            session['batch'] = student['batch']
            session['roll'] = student['roll']
            session['login'] = 1
            session['mode'] = "Student"
            session['login_mode'] = "SVV"
            if student['gender']=='F':
                session['img'] = "/static/images/woman.png"
            elif student['gender']=='M':
                session['img'] = "/static/images/man.png"
            else:
                session['img'] = "images/user.png"
            return redirect(url_for('dashboard'))
        else:
            msg = 'Incorrect Credentials !'
        # return redirect(url_for('show_login'))
    return render_template('login.html', message=msg)

def verify_email(email):
    # #print(email)
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM faculty WHERE F_email= %s', [email])
    account = cursor.fetchone()
    cursor.close()
    if account:
        msg = 'Logged in successfully !'
        session.permanent = True
        session['username'] = account['F_name'] +" "+ account['L_name']
        session['fullname'] = account['F_name'] +" "+ account['M_name']+" "+ account['L_name']
        session['svv'] = account['F_id']
        session['gender'] = account['gender']
        session['login'] = 2
        session['mode'] = "Faculty"
        session['login_mode'] = "google"
        session['img'] = account['img']
        session['dept'] = account['dept']
        session['num'] = account['F_num']
        
        # redirect(url_for('dashboard'))
        return "1"
    else:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM student WHERE S_email= %s', [email])
        student = cursor.fetchone()
        if student:
            msg = 'Logged in successfully !'
            cursor.close()            
            session['username'] = student['F_name'] +" "+ student['L_name']
            session['svv'] = student['S_id']
            session['dept'] = student['dept']
            session['sem'] = student['current_sem']
            session['batch'] = student['batch']
            session['roll'] = student['roll']
            session['login'] = 1
            session['mode'] = "Student"
            session['login_mode'] = "google"
            me = google.get('userinfo')
            response = me.data
            session['img'] = response['picture']
            # redirect(url_for('dashboard'))
            return "2"
        else:
            return "0"

from check_login import login_required



@app.route('/index/')
@login_required
def dashboard():
    print(session)
    if session['login'] == 1:
        msg = "Welcome Back "+ session['username']
        session['login'] = 2
    else :
        msg=""
        if not session.get("message") is None:
            msg=session['message']
            session.pop('message',None)
    mode = session['mode']
    svv = session['svv']
    dt = datetime.datetime.today().strftime('%Y-%m-%d')
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    qs = list()
    if mode=="Faculty":
        # cursor.execute('SELECT quiz_id,q_title,q_sub,q_date,q_time_start,q_time_end FROM quiz_det WHERE fac_inserted =%s AND q_date >= %s ORDER BY quiz_id DESC', (svv,dt))
        cursor.execute('SELECT quiz_id,q_title,q_sub,q_date,q_time_start,q_time_end FROM quiz_det WHERE fac_inserted =%s ORDER BY quiz_id DESC', [svv])
        records = cursor.fetchall()
        for row in records:
            row['q_date'] = datetime.datetime.strptime(row['q_date'], '%Y-%m-%d').strftime('%d/%m/%y')
            qs.append(row)
        # #print(qs)

    elif mode=="Student":
        if session.get('time_per_ques') is not None:
            session.pop('time_per_ques',None)
        if session.get('total_ques') is not None:
            session.pop('total_ques',None)
        if session.get('quiz_id') is not None:
            session.pop('quiz_id',None)
        if session.get('quiz_show') is not None:
            session.pop('quiz_show',None)
        if session.get('q_nos') is not None:
            session.pop('q_nos',None)
        if session.get('q_time_division') is not None:
            session.pop('q_time_division',None)
        if session.get('q_timer') is not None:
            session.pop('q_timer',None)
        if session.get('quiz_date') is not None:
            session.pop('quiz_date',None)
        if session.get('quiz_end') is not None:
            session.pop('quiz_end',None)
        if session.get('quiz_show') is not None:
            session.pop('quiz_show',None)
        if session.get('question_timer_finish') is not None:
            session.pop('question_timer_finish',None)
        if session.get('attempt_ques') is not None:
            session.pop('attempt_ques',None)
        if session.get('quiz_start') is not None:
            session.pop('quiz_start',None)
        if session.get('switch') is not None:
            session.pop('switch',None)
        if session.get('quiz_score') is not None:
            session.pop('quiz_score',None)

        dept = session['dept']
        sem = session['sem']
        batch = session['batch']
        cursor.execute('SELECT quiz_type,quiz_id,q_title,q_sub,q_date,q_time_start,q_time_end FROM quiz_det WHERE q_date >= %s AND q_dept = %s AND q_sem = %s AND q_batch="All" OR  q_batch=%s ORDER BY quiz_id DESC', (dt,dept,sem,batch))
        records = cursor.fetchall()
        cursor.close()
        # #print(len(records))
        now = datetime.datetime.now(IST)
        today_time = now.strftime('%H:%M')
        # #print(today_time)
        # #print(dt)
        if len(records)>0:
            for row in records:
                st=datetime.datetime.strptime(row['q_time_start'],'%H:%M').time()
                end=datetime.datetime.strptime(row['q_time_end'],'%H:%M').time()
                t_time=datetime.datetime.strptime(today_time,'%H:%M').time()
                # #print(row)
                # #print(type(row))
                db_date = datetime.datetime.strptime(row['q_date'], '%Y-%m-%d').date()
                row['q_date'] = datetime.datetime.strptime(row['q_date'], '%Y-%m-%d').strftime('%d/%m/%y')
                # #print('db_date:',db_date)
                # #print('type(db_date):',type(db_date))
                dt1 = datetime.datetime.strptime(dt, '%Y-%m-%d').date()
                # #print('dt:',dt)
                # #print('type(dt):',type(dt))

                # subject = 'WN'
                # # #print(subject)
                sem = 'sem'+str(session['sem'])
                # #print(sem)
                if row['quiz_type']=='0':
                    subject = row['q_sub']
                    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                    cursor.execute('SELECT subject_name,is_elective FROM subject,department WHERE subject.sem = %s AND subject.subject_name = %s AND department.dept_short = %s AND department.dept_id = subject.dept_id', (sem,subject,session['dept']))
                    elective_sub = cursor.fetchone()
                else:
                    elective_sub = {}
                    elective_sub['is_elective'] = 0
                    subject = 'Non-Subjective'
                # #print(elective_sub)
                cursor.close()
                subject_check = 0
                if elective_sub and elective_sub['is_elective'] == 1:
                    # #print("checking user elective")
                    if session['ele1'] and (session['ele1'] == elective_sub['subject_name'] or session['ele2'] == elective_sub['subject_name']):
                        subject_check = 1
                    else:
                        subject_check = 0
                else:
                    # #print("No need to check elective")
                    subject_check = 1
                # #print('subject_check:',subject_check)
                # db_date = datetime.date(row['q_date'], '%Y-%m-%d')
                if dt1 < db_date and subject_check==1:
                    # # #print("Appended1")
                    qs.append(row)
                elif (subject_check==1 and dt == db_date.strftime("%Y-%m-%d")) and  (t_time<=st or t_time<end):
                    # # #print("Appended2")
                    qs.append(row)

    
    cursor.close()
    # #print(session)
    # if len(records)>0:
    #     return render_template('index.html', message=msg,quizes = qs,total_q = len(records))
    # else:
    colors = ['bg-gradient-primary2','bg-gradient-success','bg-gradient-info','bg-gradient-warning','bg-gradient-danger','bg-gradient-dark']
    if mode=="Faculty":
        if session.get('overtime') is not None:
            session.pop('overtime',None)
            return render_template('index.html', message="You Can Edit the Quiz only before Quiz start Time!", quizes = qs,total_q = len(records),color=colors,faculty = 'yes')
    elif mode=="Student":
        if session.get('over_access') is not None:
            session.pop('over_access',None)
            return render_template('index.html', message="Student Can't Access this Page, only accessible by Faculty!", quizes = qs,total_q = len(records),color=colors,faculty='no')
    return render_template('index.html', message=msg, quizes = qs,total_q = len(records),color=colors,mode = mode)

@app.route('/profile/')
@login_required
def show_profile():
    # #print(session)
    if session['login']!=0:
        msg = ''
    else:
        msg = "Error while fetching data"
    return render_template("profile.html",message=msg)

@app.route('/signout/')
def logout():
    session.clear()
    gc.collect()
    return redirect(url_for('show_login'))

################################## Login ##########################################

if __name__ == "__main__":
    import logging
    logging.basicConfig(filename='./error.log',level=logging.DEBUG)
    print(USKS)
    app.run()

# from sample import sample
from quiz import quiz
# app.register_blueprint(sample,url_prefix="/sample")
app.register_blueprint(quiz.quiz,url_prefix="/quiz")

from student import student
app.register_blueprint(student.student,url_prefix="/student")

